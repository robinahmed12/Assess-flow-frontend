
import app from "./app";
import config from "./app/config";
import { prisma } from "./lib/prisma";
import { redisClient } from "./lib/redisClinet";


const PORT = config.port;

const main = async () => {
	try {
		await prisma.$connect();
		console.log("Connected to the database successfully.");

	    await redisClient.connect();
		console.log("Redis Connected  successfully.");

		
		app.listen(PORT, () => {
			console.log(`Server is running on port ${PORT}`);
		});
	} catch (error) {
		console.error("Error starting the server:", error);
		await prisma.$disconnect();
		process.exit(1);
	}
};

main();