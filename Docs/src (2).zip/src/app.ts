import { Invitation } from "./../node_modules/.prisma/client/index.d";
import express, { Application, Request, Response } from "express";
import cors from "cors";
import helmet from "helmet";
import { notFoundHandler } from "./app/common/middleware/not-found.middleware";
import { globalErrorHandler } from "./app/common/middleware/error.middleware";
import authRouter from "./modules/auth/auth.routes";
import recruiterRouter from "./modules/recruiter/recruiter.routes";
import companyRouter from "./modules/company/company.routes";
import problemRouter from "./modules/problem/problem.routes";
import assessmentRouter from "./modules/assessment/assessment.routes";
import invitationRouter from "./modules/invitation/invitation.routes";
import candidateRouter from "./modules/candidate/candidate.routes";
import attemptRouter from "./modules/attempt/attempt.routes";
import evaluationRouter from "./modules/evaluation/evaluation.routes";
import { adminRouter } from "./modules/admin";
import paymentRouter, {
  paymentWebhookRouter,
} from "./modules/payment/payment.routes";
import {
  bkashPaymentCallbackRouter,
  bkashPaymentRouter,
} from "./modules/bkash-payment";


import { swaggerSpec } from "./app/config/swagger";
import swaggerUi from "swagger-ui-express";
import { dashboardRouter } from "./modules/dashboard";

const app: Application = express();

app.use(helmet());

app.use(
  cors({
    origin: true,
    credentials: true,
  }),
);

app.use(express.json());

app.get("/api/v1/health", (_req: Request, res: Response) => {
  res.status(200).json({
    success: true,
    message: "API is running",
    data: {
      status: "ok",
    },
  });
});

app.use("/api/v1/auth", authRouter);
app.use("/api/v1/recruiters", recruiterRouter);
app.use("/api/v1/companies", companyRouter);
app.use("/api/v1/problems", problemRouter);
app.use("/api/v1/assessments", assessmentRouter);
app.use("/api/v1/invitations", invitationRouter);
app.use("/api/v1/candidate", candidateRouter);
app.use("/api/v1/attempts", attemptRouter);
app.use("/api/v1/evaluation", evaluationRouter);
app.use("/api/v1/stripe-payments", paymentWebhookRouter);
app.use("/api/v1/stripe-payments", paymentRouter);
app.use("/api/v1/admin", adminRouter);
app.use("/api/v1/bkash-payments", bkashPaymentCallbackRouter);
app.use("/api/v1/bkash-payments", bkashPaymentRouter);
app.use("/api/v1", bkashPaymentCallbackRouter);
app.use("/api/v1/dashboard", dashboardRouter);
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));

/*
|--------------------------------------------------------------------------
| 404 Handler
|--------------------------------------------------------------------------
*/

app.use(notFoundHandler);

/*
|--------------------------------------------------------------------------
| Global Error Handler
|--------------------------------------------------------------------------
*/

app.use(globalErrorHandler);

export default app;
